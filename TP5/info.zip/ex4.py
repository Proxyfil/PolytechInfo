from tkinter import N


nombres = [1, -1, 2, -2, 3, -3, 0]
print(nombres.sort())
print(nombres)
print("")
nombres = [1, -1, 2, -2, 3, -3, 0]
print(sorted(nombres, reverse=True))
print(nombres)
