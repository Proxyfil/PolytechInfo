nombres = [n for n in range(20)]
print(nombres)
print(nombres[2:18:2])
print(nombres[::3])
print(nombres[::-1])